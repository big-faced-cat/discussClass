url_prefix="http://192.168.0.202:10030";
ID_GRADE="3";//年级类目id
ID_CLASS="4";//班级类目id
ID_CLASSROOM="5";//班级类目id
ID_TEACHERS="11";//教师类目id
ID_COURSE_LIST="0";//学科种类类目id
ID_COURSE_TYPE="2";//课程种类类目id
ID_KEPING_TYPE="10";//课评方式类目id
ID_CLASS_DURATIONID="1";//课时类目id

FILE_SIZE=5*1024;//上传文件大小
